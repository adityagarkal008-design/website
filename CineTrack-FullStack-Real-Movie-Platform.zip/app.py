import os, sqlite3
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "instance", "cinetrack.db")
TMDB_TOKEN = os.getenv("TMDB_TOKEN", "").strip()
TMDB_BASE = "https://api.themoviedb.org/3"

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-in-production")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      bio TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ratings(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      movie_id INTEGER NOT NULL,
      rating REAL NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(user_id,movie_id),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS reviews(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      movie_id INTEGER NOT NULL,
      movie_title TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS watchlist(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      movie_id INTEGER NOT NULL,
      movie_title TEXT NOT NULL,
      poster_path TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      UNIQUE(user_id,movie_id),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS diary(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      movie_id INTEGER NOT NULL,
      movie_title TEXT NOT NULL,
      watched_on TEXT NOT NULL,
      rating REAL,
      note TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    con.commit()
    con.close()

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    con = db()
    user = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    con.close()
    return user

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in to use your personal movie features.", "info")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper

def tmdb_headers():
    return {"Authorization": f"Bearer {TMDB_TOKEN}", "accept": "application/json"}

def tmdb_get(path, params=None):
    if not TMDB_TOKEN:
        return None
    try:
        r = requests.get(TMDB_BASE + path, headers=tmdb_headers(), params=params or {}, timeout=8)
        r.raise_for_status()
        return r.json()
    except requests.RequestException:
        return None

@app.context_processor
def inject():
    return {"user": current_user(), "tmdb_enabled": bool(TMDB_TOKEN)}

@app.route("/")
def home():
    data = tmdb_get("/trending/movie/week", {"language":"en-US"})
    movies = (data or {}).get("results", [])[:12]
    return render_template("index.html", movies=movies)

@app.route("/discover")
def discover():
    q = request.args.get("q", "").strip()
    if q:
        data = tmdb_get("/search/movie", {"query":q, "include_adult":"false", "language":"en-US", "page":1}) or {}
        movies = data.get("results", [])
    else:
        data = tmdb_get("/movie/popular", {"language":"en-US","page":1}) or {}
        movies = data.get("results", [])
    return render_template("discover.html", movies=movies, q=q)

@app.route("/movie/<int:movie_id>")
def movie(movie_id):
    details = tmdb_get(f"/movie/{movie_id}", {"language":"en-US", "append_to_response":"credits,videos"}) or {}
    con = db()
    reviews = con.execute("""SELECT reviews.*, users.username FROM reviews
        JOIN users ON users.id=reviews.user_id WHERE movie_id=? ORDER BY reviews.id DESC""",(movie_id,)).fetchall()
    avg = con.execute("SELECT AVG(rating) a, COUNT(*) c FROM ratings WHERE movie_id=?", (movie_id,)).fetchone()
    mine = None
    saved = False
    if session.get("user_id"):
        mine = con.execute("SELECT rating FROM ratings WHERE user_id=? AND movie_id=?",(session["user_id"],movie_id)).fetchone()
        saved = bool(con.execute("SELECT 1 FROM watchlist WHERE user_id=? AND movie_id=?",(session["user_id"],movie_id)).fetchone())
    con.close()
    return render_template("movie.html", movie=details, reviews=reviews, avg=avg, mine=mine, saved=saved)

@app.route("/api/search")
def api_search():
    q = request.args.get("q","").strip()
    if not q:
        return jsonify([])
    data = tmdb_get("/search/movie", {"query":q,"include_adult":"false","language":"en-US","page":1}) or {}
    return jsonify(data.get("results",[])[:10])

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username=request.form["username"].strip()
        email=request.form["email"].strip().lower()
        password=request.form["password"]
        if len(password)<6:
            flash("Password must contain at least 6 characters.","error")
            return render_template("auth.html", mode="register")
        con=db()
        try:
            con.execute("INSERT INTO users(username,email,password,created_at) VALUES(?,?,?,?)",
                        (username,email,generate_password_hash(password),datetime.utcnow().isoformat()))
            con.commit()
            user=con.execute("SELECT id FROM users WHERE email=?",(email,)).fetchone()
            session["user_id"]=user["id"]
            return redirect(url_for("home"))
        except sqlite3.IntegrityError:
            flash("Username or email is already registered.","error")
        finally: con.close()
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        identity=request.form["identity"].strip().lower()
        password=request.form["password"]
        con=db()
        u=con.execute("SELECT * FROM users WHERE lower(email)=? OR lower(username)=?",(identity,identity)).fetchone()
        con.close()
        if u and check_password_hash(u["password"],password):
            session.clear(); session["user_id"]=u["id"]
            return redirect(request.args.get("next") or url_for("home"))
        flash("Invalid login details.","error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/watchlist")
@login_required
def watchlist_page():
    con=db()
    rows=con.execute("SELECT * FROM watchlist WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    con.close()
    return render_template("watchlist.html", rows=rows)

@app.post("/watchlist/toggle")
@login_required
def watchlist_toggle():
    movie_id=int(request.form["movie_id"])
    title=request.form.get("movie_title","Movie")
    poster=request.form.get("poster_path","")
    con=db()
    exists=con.execute("SELECT id FROM watchlist WHERE user_id=? AND movie_id=?",(session["user_id"],movie_id)).fetchone()
    if exists:
        con.execute("DELETE FROM watchlist WHERE id=?",(exists["id"],))
        state=False
    else:
        con.execute("INSERT INTO watchlist(user_id,movie_id,movie_title,poster_path,created_at) VALUES(?,?,?,?,?)",
                    (session["user_id"],movie_id,title,poster,datetime.utcnow().isoformat()))
        state=True
    con.commit(); con.close()
    return jsonify({"saved":state})

@app.post("/rate")
@login_required
def rate():
    con=db()
    con.execute("""INSERT INTO ratings(user_id,movie_id,rating,created_at) VALUES(?,?,?,?)
                   ON CONFLICT(user_id,movie_id) DO UPDATE SET rating=excluded.rating,created_at=excluded.created_at""",
                (session["user_id"],int(request.form["movie_id"]),float(request.form["rating"]),datetime.utcnow().isoformat()))
    con.commit(); con.close()
    flash("Your rating was saved.","success")
    return redirect(request.referrer or url_for("home"))

@app.post("/review")
@login_required
def review():
    body=request.form["body"].strip()
    if not body:
        flash("Write something before posting your review.","error")
        return redirect(request.referrer or url_for("home"))
    con=db()
    con.execute("INSERT INTO reviews(user_id,movie_id,movie_title,body,created_at) VALUES(?,?,?,?,?)",
                (session["user_id"],int(request.form["movie_id"]),request.form.get("movie_title","Movie"),body,datetime.utcnow().isoformat()))
    con.commit(); con.close()
    flash("Review published.","success")
    return redirect(request.referrer or url_for("home"))

@app.route("/diary")
@login_required
def diary_page():
    con=db()
    rows=con.execute("SELECT * FROM diary WHERE user_id=? ORDER BY watched_on DESC,id DESC",(session["user_id"],)).fetchall()
    con.close()
    return render_template("diary.html", rows=rows)

@app.post("/diary")
@login_required
def diary_add():
    con=db()
    con.execute("""INSERT INTO diary(user_id,movie_id,movie_title,watched_on,rating,note,created_at)
                   VALUES(?,?,?,?,?,?,?)""",
                (session["user_id"],int(request.form["movie_id"]),request.form["movie_title"],
                 request.form["watched_on"],request.form.get("rating") or None,request.form.get("note",""),
                 datetime.utcnow().isoformat()))
    con.commit(); con.close()
    flash("Added to your diary.","success")
    return redirect(url_for("diary_page"))

@app.route("/profile/<username>")
def profile(username):
    con=db()
    u=con.execute("SELECT * FROM users WHERE lower(username)=lower(?)",(username,)).fetchone()
    if not u:
        con.close(); return "User not found",404
    stats=con.execute("""SELECT
      (SELECT COUNT(*) FROM ratings WHERE user_id=?) watched,
      (SELECT COUNT(*) FROM reviews WHERE user_id=?) reviews,
      (SELECT COUNT(*) FROM watchlist WHERE user_id=?) watchlist""",(u["id"],u["id"],u["id"])).fetchone()
    recent=con.execute("SELECT * FROM reviews WHERE user_id=? ORDER BY id DESC LIMIT 6",(u["id"],)).fetchall()
    con.close()
    return render_template("profile.html", profile=u, stats=stats, recent=recent)

@app.route("/profile")
@login_required
def my_profile():
    return redirect(url_for("profile", username=current_user()["username"]))

if __name__ == "__main__":
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    init_db()
    app.run(debug=True)