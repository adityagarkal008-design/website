# CineTrack Full-Stack 🎬

A Letterboxd-inspired **original** movie tracking platform built with Flask, SQLite, HTML/CSS/JavaScript and the TMDB API.

## Features
- Real movie search and trending/popular movie data via TMDB
- User registration/login with hashed passwords
- Persistent SQLite database
- Watchlist
- Ratings
- Reviews
- Viewing diary
- User profiles and stats
- Responsive cinematic UI
- TMDB API kept on the server via an environment variable

## 1. Install
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## 2. TMDB token
Create a TMDB account and obtain an API Read Access Token. Put it in an environment variable named `TMDB_TOKEN`. Do not commit the token to GitHub.

Windows PowerShell:
```powershell
$env:TMDB_TOKEN="YOUR_TOKEN"
$env:SECRET_KEY="YOUR_RANDOM_SECRET"
python app.py
```

macOS/Linux:
```bash
export TMDB_TOKEN="YOUR_TOKEN"
export SECRET_KEY="YOUR_RANDOM_SECRET"
python app.py
```

Without TMDB_TOKEN, the account/database pages still work, but live movie discovery is unavailable.

## 3. Run
```bash
python app.py
```
Open http://127.0.0.1:5000

## 4. Production hosting
Use a Python-capable host such as Render, Railway, Fly.io, PythonAnywhere, or a VPS. Set `TMDB_TOKEN` and `SECRET_KEY` in the host's environment variables. The included `requirements.txt` contains Gunicorn for production WSGI serving.

### Important
SQLite is excellent for a college/demo project. For a high-traffic public production service, move the database to PostgreSQL and use a persistent disk/database service.

## TMDB attribution
This project uses TMDB API data. Review and comply with TMDB's current terms of use and attribution requirements before public deployment.
